BD Profile Agent - guided demo (self-contained)
================================================
Needs only Python 3 (no pip installs; all JS is bundled locally).

Run:
  cd into this folder, then:
    python3 ui/server.py          (Mac/Linux)
    py ui/server.py               (Windows)

Open:  http://127.0.0.1:8765/live

Present: click through the Teams chat, press "Watch the run live",
arrow keys / Space advance, F = fullscreen, C = presenter cursor on/off.
The .docx file card downloads the real compiled Union profile from
03-compile/output/. Works fully offline.
